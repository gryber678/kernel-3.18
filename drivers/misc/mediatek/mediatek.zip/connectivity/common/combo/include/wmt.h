
#ifndef _MTKWMT_H_
#define _MTKWMT_H_
#include "wmt_core.h"



#endif /*_MTKWMT_H_*/
