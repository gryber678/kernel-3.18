#ifndef _WMT_PLAT_STUB_H_
#define _WMT_PLAT_STUB_H_


INT32 wmt_plat_audio_ctrl(CMB_STUB_AIF_X state, CMB_STUB_AIF_CTRL ctrl);

INT32 wmt_plat_stub_init(VOID);

#endif /*_WMT_PLAT_STUB_H_*/
