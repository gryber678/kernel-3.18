
#ifndef _WMT_CHRDEV_WIFI_H_
#define _WMT_CHRDEV_WIFI_H_


int wifi_reset_start(void);
int wifi_reset_end(void);


#endif /*_WMT_CHRDEV_WIFI_H_*/
